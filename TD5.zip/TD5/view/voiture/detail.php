
<body>

	<?php
	
	echo " 
	<ul>
	<li>Marque : " .  htmlspecialchars($v->getMarque()) . "</li>
	<li>Couleur : " .  htmlspecialchars($v->getCouleur()) . "</li>
	<li>Immatriculation : " .  htmlspecialchars($v->getImmatriculation()) . "</li>
	</ul>";
	?>
</body>

