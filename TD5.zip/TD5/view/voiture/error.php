
<body>
     <?php
     $immatHTML = htmlspecialchars($immat);
     $immatURL = rawurlencode($immat);
        echo "La voiture immatriculée : " .  $immatHTML . " n'est pas repertoriée." ;
        ?>
</body>

