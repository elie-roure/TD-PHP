<body>
	
	<p>La voiture a bien été créée</p>
	<?php

	require 'list.php';

	 ?>


</body>